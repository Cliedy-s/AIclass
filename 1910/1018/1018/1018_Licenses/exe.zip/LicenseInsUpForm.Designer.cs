﻿namespace _1018_Licenses
{
    partial class LicenseInsUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLicenseID = new System.Windows.Forms.TextBox();
            this.txtLicenseName = new System.Windows.Forms.TextBox();
            this.txtLicenseCost = new System.Windows.Forms.TextBox();
            this.submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "LicenseID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "LicenseName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "LicenseCost";
            // 
            // txtLicenseID
            // 
            this.txtLicenseID.Location = new System.Drawing.Point(136, 22);
            this.txtLicenseID.Name = "txtLicenseID";
            this.txtLicenseID.Size = new System.Drawing.Size(140, 21);
            this.txtLicenseID.TabIndex = 0;
            // 
            // txtLicenseName
            // 
            this.txtLicenseName.Location = new System.Drawing.Point(136, 58);
            this.txtLicenseName.Name = "txtLicenseName";
            this.txtLicenseName.Size = new System.Drawing.Size(140, 21);
            this.txtLicenseName.TabIndex = 1;
            // 
            // txtLicenseCost
            // 
            this.txtLicenseCost.Location = new System.Drawing.Point(136, 93);
            this.txtLicenseCost.Name = "txtLicenseCost";
            this.txtLicenseCost.Size = new System.Drawing.Size(140, 21);
            this.txtLicenseCost.TabIndex = 2;
            this.txtLicenseCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtLicenseCost_KeyPress);
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(201, 136);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(75, 23);
            this.submit.TabIndex = 3;
            this.submit.Text = "submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // LicenseInsUpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 182);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.txtLicenseCost);
            this.Controls.Add(this.txtLicenseName);
            this.Controls.Add(this.txtLicenseID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "LicenseInsUpForm";
            this.Text = "LicenseInsUpForm";
            this.Load += new System.EventHandler(this.LicenseInsUpForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLicenseID;
        private System.Windows.Forms.TextBox txtLicenseName;
        private System.Windows.Forms.TextBox txtLicenseCost;
        private System.Windows.Forms.Button submit;
    }
}