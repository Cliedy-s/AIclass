﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineProject.DTO
{
    public class ProductionDTO
    {
        public string ProductionID { get; set; }
        public string ProductionName { get; set; }
    }
}
